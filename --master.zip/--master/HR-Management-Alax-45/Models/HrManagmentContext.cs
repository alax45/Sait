﻿using Microsoft.EntityFrameworkCore;

namespace HR_Management_Alax_45.Models
{
    public class HrManagementContext : DbContext
    {
        public HrManagementContext(DbContextOptions<HrManagementContext> options)
            : base(options)
        { }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Meeting> Meetings { get; set; }
    }
}
