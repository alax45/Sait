﻿using System.ComponentModel.DataAnnotations;

namespace HR_Management_Alax_45.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100, MinimumLength = 3)]
        public string FullName { get; set; }

        [Required]
        public string Gender { get; set; }

        [Required]
        [Range(18, 120, ErrorMessage = "Age must be between 18 and 120 years.")]
        public int Age { get; set; }

        [Required(ErrorMessage = "Please provide your phone number.")]
        [Phone(ErrorMessage = "Please enter a valid phone number (e.g. +1-234-567-8901).")]
        [RegularExpression(@"^\+?\d{1,4}?[-.\s]?\(?\d{1,3}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}$", ErrorMessage = "Invalid phone number format.")]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessage = "Email address is required.")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address, like example@domain.com.")]
        [RegularExpression(@"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$", ErrorMessage = "Please provide a valid email address.")]
        public string Email { get; set; }

        [Required]
        public string Country { get; set; }

        [Required]
        [StringLength(100, MinimumLength = 8, ErrorMessage = "Password must be at least 8 characters long.")]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$",
            ErrorMessage = "Password must contain uppercase and lowercase letters, numbers, and special characters.")]
        public string Password { get; set; }

        public string? PasswordHash { get; set; }

        public string? ResetToken { get; set; }
        public DateTime? ResetTokenExpiry { get; set; }
    }
}
