﻿namespace HR_Management_Alax_45.Models
{
    public class Meeting
    {
        public int Id { get; set; }
        public DateTime DateTime { get; set; }
        public string Location { get; set; }

        public int UserId { get; set; }
        public User User { get; set; }
    }
}
