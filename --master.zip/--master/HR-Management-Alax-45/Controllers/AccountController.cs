﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Text;
using System.Security.Cryptography;
using System.Threading.Tasks;
using HR_Management_Alax_45.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace HR_Management_Alax_45.Controllers
{
    public class AccountController : Controller
    {
        private readonly HrManagementContext _context;
        private readonly ILogger<AccountController> _logger;

        public AccountController(HrManagementContext context, ILogger<AccountController> logger)
        {
            _context = context;
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(string email, string password, string recaptchaResponse)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                ViewBag.ErrorMessage = "Email and Password are required.";
                return View();
            }

            // Перевірка reCAPTCHA
            var isCaptchaValid = await ValidateCaptcha(recaptchaResponse);
            if (!isCaptchaValid)
            {
                ViewBag.ErrorMessage = "Captcha validation failed.";
                return View();
            }

            // Хешування пароля
            var hashedPassword = HashPassword(password);

            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Email == email && u.Password == hashedPassword);

            if (user == null)
            {
                _logger.LogWarning($"Failed login attempt for email: {email}");
                ViewBag.ErrorMessage = "Invalid credentials.";
                return View();
            }

            var claims = new[]
            {
        new Claim(ClaimTypes.Name, user.FullName),
        new Claim(ClaimTypes.Email, user.Email)
    };

            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);

            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

            _logger.LogInformation($"User {email} logged in successfully.");
            return RedirectToAction("Index", "Main");
        }

        private async Task<bool> ValidateCaptcha(string recaptchaResponse)
        {
            var secretKey = "6Ld6Ta4qAAAAALIlcfwlW8LfF-Vba8QrIod7cwrJ"; 
            var client = new HttpClient();
            var response = await client.PostAsync("https://www.google.com/recaptcha/api/siteverify", new FormUrlEncodedContent(new[]
            {
        new KeyValuePair<string, string>("secret", secretKey),
        new KeyValuePair<string, string>("response", recaptchaResponse)
    }));

            var jsonResponse = await response.Content.ReadAsStringAsync();
            dynamic jsonData = JsonConvert.DeserializeObject(jsonResponse);

            return jsonData.success == true;
        }

        [HttpGet]
        public IActionResult ForgotPassword()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ForgotPassword(string email)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);

            if (user == null)
            {
                ViewBag.ErrorMessage = "Email not found.";
                return View();
            }

            // Генерація та збереження токену для скидання пароля
            string resetToken = GenerateResetToken();
            user.ResetToken = resetToken;
            user.ResetTokenExpiry = DateTime.UtcNow.AddHours(1);
            await _context.SaveChangesAsync();

            await SendEmail(email, "Password Reset", $"Your reset token is: {resetToken}");

            ViewBag.SuccessMessage = "A recovery email has been sent.";
            return View();
        }

        [HttpGet]
        public IActionResult ResetPassword(string token)
        {
            // Token validation logic
            if (string.IsNullOrEmpty(token))
            {
                ViewBag.ErrorMessage = "Invalid reset token.";
                return View("Error");
            }

            ViewBag.Token = token;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ResetPassword(string token, string newPassword)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.ResetToken == token);

            // Перевірка, чи існує користувач і чи не минув термін дії токена
            if (user == null || user.ResetTokenExpiry < DateTime.UtcNow)
            {
                ViewBag.ErrorMessage = "Invalid or expired reset token.";
                return View();
            }

            // Оновлення пароля користувача
            user.Password = HashPassword(newPassword);
            user.ResetToken = null; // Очищення токена
            user.ResetTokenExpiry = null; // Очищення терміну дії токена
            await _context.SaveChangesAsync();

            _logger.LogInformation($"Password reset for user {user.Email}.");
            return RedirectToAction("Login");
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(User model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Check if email already exists
            if (await _context.Users.AnyAsync(u => u.Email == model.Email))
            {
                ModelState.AddModelError("", "User with this Email is already exist! Please Login");
                return View(model);
            }

            // Hash password
            model.Password = HashPassword(model.Password);

            _context.Users.Add(model);
            await _context.SaveChangesAsync();

            _logger.LogInformation($"User {model.Email} registered successfully.");
            return RedirectToAction("Login");
        }

        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            _logger.LogInformation("User logged out.");
            return RedirectToAction("Login");
        }

        private string HashPassword(string password)
        {
            using var sha256 = SHA256.Create();
            var bytes = Encoding.UTF8.GetBytes(password);
            var hash = sha256.ComputeHash(bytes);
            return Convert.ToBase64String(hash);
        }

        private string GenerateResetToken()
        {
            return Guid.NewGuid().ToString();
        }

        private Task SendEmail(string email, string subject, string body)
        {
            // Add email-sending logic
            return Task.CompletedTask;
        }
    }
}
